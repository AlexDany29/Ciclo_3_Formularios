﻿using Problema1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Problema1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //List< TIPO DE DATO > Alumnos = new List< TIPO DE DATO >();

        List<Alumno> lstalumnos = new List<Alumno>();

        private void btnagregar_Click(object sender, EventArgs e)

         // 1 forma de agregar datos
        {
            Alumno alumno = new Alumno();
            alumno.id = 1;
            alumno.nombres = "Juan";
            alumno.apellidos = "Perez";
            alumno.idseccion = 1;
            alumno.pension = 500.00m;
            alumno.fecha = DateTime.Now;
            lstalumnos.Add(alumno);

            Alumno alumno2 = new Alumno();
            alumno2.id = 2;
            alumno2.nombres = "Josef";
            alumno2.apellidos = "Stalin";
            alumno2.idseccion = 1;
            alumno2.pension = 300.00m;
            alumno2.fecha = DateTime.Now.Date;
            lstalumnos.Add(alumno2);


            // 2 forma de agregar datos

            Alumno alumno3 = new Alumno
            {
                id = 3,
                nombres = "Cesar",
                apellidos = "Acuña",
                idseccion = 1,
                pension = 350m,
                fecha = DateTime.Now,

            };
            lstalumnos.Add(alumno3);

           dgvalumno.DataSource = lstalumnos;

        }


        //MODIFICAR DATOS
        private void Modificar_Click(object sender, EventArgs e)
        {
            Alumno obj = lstalumnos.FirstOrDefault(a =>a.id== 3);
            if (obj != null) 
            {
                obj.id = 3;
                obj.nombres = "sasha";
                obj.apellidos = "Uzumaki";
                obj.idseccion = 1;
                obj.pension = 350m;
                obj.fecha = DateTime.Now;
            }
            dgvalumno.DataSource = null;
            dgvalumno.DataSource = lstalumnos;
        }


        //ELIMINAR DATOS
        private void eliminar_Click(object sender, EventArgs e)
        {
            Alumno obj = lstalumnos.FirstOrDefault(a => a.id == 1);
            if (obj != null)            
            {
                lstalumnos.Remove(obj);
                dgvalumno.DataSource = null;
                dgvalumno.DataSource = lstalumnos;

            }
            else
            {
                MessageBox.Show("No se econtro al alumno");
            }
        }


        //HACER DESGLOSE DE OPCIONES
        private void combosecciones_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<seccion> secciones = new List<seccion>
            {
              new seccion { id = 0, texto = "---Seleccione---" },
              new seccion { id = 1, texto = "Seccion A" },
              new seccion { id = 2, texto = "Seccion B" },
              new seccion { id = 3, texto = "Seccion C" },
              new seccion { id = 4, texto = "Seccion D" },
            };
   
            combosecciones.DataSource = secciones;
            combosecciones.DisplayMember = "texto";
            combosecciones.ValueMember = "id";
            combosecciones.SelectedIndex = 0;

        }


    }
}
