﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema1.Clases
{
    public class Alumno
    {

        // CLASE "ATRIBUTOS"
        public int id { get; set; }
        public string nombres { get; set; }
        public string apellidos { get; set; }
        public int idseccion { get; set; }
        public decimal pension { get; set; }
        public DateTime fecha { get; set; }

    }
}
