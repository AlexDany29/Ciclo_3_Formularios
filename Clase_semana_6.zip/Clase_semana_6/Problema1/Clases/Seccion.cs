﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema1.Clases
{
    public class seccion
    {
        public int id {  get; set; }
        public string texto { get; set; }
    }
}
