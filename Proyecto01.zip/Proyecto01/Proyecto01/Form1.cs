﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double nota1 = Convert.ToDouble(txtnota1.Text);
            double nota2 = Convert.ToDouble(txtnota2.Text);

            if (nota1 >= 0 && nota1 <= 20 && nota2 >= 0 && nota2 <=20)
            {
                double suma = (nota1 + nota2);
                double promedio = suma / 2;
                Resultado.Text = promedio.ToString();
            }
            else
            {
                MessageBox.Show("La nota debe ser entre 0 y 20, Fuera de rango");
            }
        }

        private void Resultado_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
