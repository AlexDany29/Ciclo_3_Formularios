﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtcalcular_Click(object sender, EventArgs e)
        {
            
            //------------------1ERA FORMA-------------------------------------

            int habitaciones = Convert.ToInt32(txthabitaciones.Text);
            int banios = Convert.ToInt32(txtbanios.Text);
            int patios = Convert.ToInt32(txtpatios.Text);

            //Calculo:        

            //double totalhabitaciones = habitaciones * 30;
            //double totalbanios = banios * 10;
            //double totalpatios = patios * 15;

            
           /* //--------------------2DA FORMA------------------------------------
            
            if (!int.TryParse(txthabitaciones.Text, out int habitaciones) ||
               !int.TryParse(txtbanios.Text, out int banios) ||
               !int.TryParse(txtpatios.Text, out int patios))
              {
                MessageBox.Show("Valor incorrecto, solo se permiten numeros enteros", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
              }
            */
            

            /*double totalhabitaciones = habitaciones * 30;
            double totalbanios = banios * 10;
            double totalpatios = patios * 15;
            */
            /*double totalpagos = totalhabitaciones + totalbanios + totalpatios;
            string texto1 = " El pago total de habitacion será: " + totalhabitaciones;
            string texto2 = " El pago total de baños será: " + totalbanios;
            string texto3 = " El pago total de patios será: " + totalpatios;
            string texto4 = " El pago total será: " + totalpagos;
            txtresultado.Text = texto1.ToString() + texto2.ToString() + texto3.ToString() + texto4.ToString();
            */
            //-------------------3ERA FORMA---------------------------------

            var sb =new StringBuilder();
           

            sb.AppendLine($"=========DETALLE DE ALQUILER=========\r\n");
            sb.AppendLine($"Habitaciones {habitaciones} x 30: S/.{habitaciones * 30:F2}\r\n");
            sb.AppendLine($"Baños {banios} x 10: S/.{banios * 10:F2}\r\n");
            sb.AppendLine($"Patios {patios} x 35: S/.{patios * 15:F2}\r\n");
            sb.AppendLine($"------------------------------------------\r\n");
            double totalpagos = (habitaciones * 30) + (banios * 10) + (patios * 15);
            sb.AppendLine($"Total a pagar: {totalpagos:F2}\r\n");

            txtresultado.Text = sb.ToString();

        }
    }
}
