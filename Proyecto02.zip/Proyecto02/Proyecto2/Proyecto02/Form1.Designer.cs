﻿namespace Proyecto02
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txthabitaciones = new System.Windows.Forms.TextBox();
            this.txtbanios = new System.Windows.Forms.TextBox();
            this.txtpatios = new System.Windows.Forms.TextBox();
            this.banios = new System.Windows.Forms.Label();
            this.patios = new System.Windows.Forms.Label();
            this.habitaciones = new System.Windows.Forms.Label();
            this.txtcalcular = new System.Windows.Forms.Button();
            this.txtresultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txthabitaciones
            // 
            this.txthabitaciones.Location = new System.Drawing.Point(377, 37);
            this.txthabitaciones.Name = "txthabitaciones";
            this.txthabitaciones.Size = new System.Drawing.Size(100, 20);
            this.txthabitaciones.TabIndex = 0;
            this.txthabitaciones.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbanios
            // 
            this.txtbanios.Location = new System.Drawing.Point(377, 63);
            this.txtbanios.Name = "txtbanios";
            this.txtbanios.Size = new System.Drawing.Size(100, 20);
            this.txtbanios.TabIndex = 1;
            this.txtbanios.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtpatios
            // 
            this.txtpatios.Location = new System.Drawing.Point(377, 90);
            this.txtpatios.Name = "txtpatios";
            this.txtpatios.Size = new System.Drawing.Size(100, 20);
            this.txtpatios.TabIndex = 2;
            this.txtpatios.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // banios
            // 
            this.banios.AutoSize = true;
            this.banios.Location = new System.Drawing.Point(300, 66);
            this.banios.Name = "banios";
            this.banios.Size = new System.Drawing.Size(37, 13);
            this.banios.TabIndex = 4;
            this.banios.Text = "Baños";
            // 
            // patios
            // 
            this.patios.AutoSize = true;
            this.patios.Location = new System.Drawing.Point(301, 93);
            this.patios.Name = "patios";
            this.patios.Size = new System.Drawing.Size(36, 13);
            this.patios.TabIndex = 5;
            this.patios.Text = "Patios";
            // 
            // habitaciones
            // 
            this.habitaciones.AutoSize = true;
            this.habitaciones.Location = new System.Drawing.Point(301, 37);
            this.habitaciones.Name = "habitaciones";
            this.habitaciones.Size = new System.Drawing.Size(69, 13);
            this.habitaciones.TabIndex = 6;
            this.habitaciones.Text = "Habitaciones";
            // 
            // txtcalcular
            // 
            this.txtcalcular.Location = new System.Drawing.Point(377, 116);
            this.txtcalcular.Name = "txtcalcular";
            this.txtcalcular.Size = new System.Drawing.Size(100, 23);
            this.txtcalcular.TabIndex = 7;
            this.txtcalcular.Text = "Calcular";
            this.txtcalcular.UseVisualStyleBackColor = true;
            this.txtcalcular.Click += new System.EventHandler(this.txtcalcular_Click);
            // 
            // txtresultado
            // 
            this.txtresultado.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txtresultado.Location = new System.Drawing.Point(98, 161);
            this.txtresultado.Multiline = true;
            this.txtresultado.Name = "txtresultado";
            this.txtresultado.ReadOnly = true;
            this.txtresultado.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtresultado.Size = new System.Drawing.Size(647, 260);
            this.txtresultado.TabIndex = 9;
            this.txtresultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtresultado);
            this.Controls.Add(this.txtcalcular);
            this.Controls.Add(this.habitaciones);
            this.Controls.Add(this.patios);
            this.Controls.Add(this.banios);
            this.Controls.Add(this.txtpatios);
            this.Controls.Add(this.txtbanios);
            this.Controls.Add(this.txthabitaciones);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txthabitaciones;
        private System.Windows.Forms.TextBox txtbanios;
        private System.Windows.Forms.TextBox txtpatios;
        private System.Windows.Forms.Label banios;
        private System.Windows.Forms.Label patios;
        private System.Windows.Forms.Label habitaciones;
        private System.Windows.Forms.Button txtcalcular;
        private System.Windows.Forms.TextBox txtresultado;
    }
}

